lista = []
slownik = {}